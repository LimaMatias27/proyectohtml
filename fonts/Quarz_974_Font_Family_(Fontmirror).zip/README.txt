To learn more about the font family and its license, visit https://www.fontmirror.com/quarz-974

To learn more about the font, visit https://www.hellofont.com/fonts/472.